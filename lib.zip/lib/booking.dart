import 'package:flutter/material.dart';

class BookingPage extends StatelessWidget {
  const BookingPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F5F5),

      // ================= APP BAR =================
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          "Book a ride",
          style: TextStyle(color: Colors.black),
        ),
        centerTitle: true,
      ),

      // ================= BODY =================
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              "Available Drivers",
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 14,
              ),
            ),

            const SizedBox(height: 12),

            Expanded(
              child: ListView(
                children: const [
                  DriverCard(
                    name: "Ahmad Zaki",
                    rating: 4.9,
                    car: "Perodua Myvi - ABC1234",
                    price: "RM 5.00",
                    color: Colors.orange,
                  ),
                  DriverCard(
                    name: "Fatimah Ali",
                    rating: 4.8,
                    car: "Proton Saga - ALA1010",
                    price: "RM 5.50",
                    color: Colors.pink,
                  ),
                  DriverCard(
                    name: "Sofia Aina",
                    rating: 4.8,
                    car: "Proton Iris - VAD6789",
                    price: "RM 6.00",
                    color: Colors.purple,
                  ),
                  DriverCard(
                    name: "Kamal",
                    rating: 4.8,
                    car: "Perodua Bezza - CAD4321",
                    price: "RM 6.00",
                    color: Colors.brown,
                  ),
                  DriverCard(
                    name: "Ammar Ali",
                    rating: 4.8,
                    car: "Perodua Myvi - ABA4020",
                    price: "RM 5.50",
                    color: Colors.teal,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),

      // ================= BOTTOM NAV =================
      bottomNavigationBar: BottomNavigationBar(
        selectedItemColor: const Color(0xFF0D7C7B),
        unselectedItemColor: Colors.grey,
        type: BottomNavigationBarType.fixed,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: "Home",
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.directions_car),
            label: "My Rides",
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.chat_bubble_outline),
            label: "Chat",
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person_outline),
            label: "Profile",
          ),
        ],
      ),
    );
  }
}

// ================= DRIVER CARD =================
class DriverCard extends StatelessWidget {
  final String name;
  final double rating;
  final String car;
  final String price;
  final Color color;

  const DriverCard({
    super.key,
    required this.name,
    required this.rating,
    required this.car,
    required this.price,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: const Color(0xFF0D7C7B),
          width: 1,
        ),
      ),
      child: Row(
        children: [
          // Avatar
          CircleAvatar(
            backgroundColor: color,
            child: Text(
              name[0],
              style: const TextStyle(color: Colors.white),
            ),
          ),

          const SizedBox(width: 12),

          // Driver info
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  name,
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 14,
                  ),
                ),
                const SizedBox(height: 4),
                Row(
                  children: [
                    const Icon(Icons.star, size: 14, color: Colors.orange),
                    const SizedBox(width: 4),
                    Text(
                      rating.toString(),
                      style: const TextStyle(fontSize: 12),
                    ),
                  ],
                ),
                const SizedBox(height: 4),
                Text(
                  car,
                  style: const TextStyle(
                    fontSize: 12,
                    color: Colors.grey,
                  ),
                ),
              ],
            ),
          ),

          // Price & Select
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                price,
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 13,
                ),
              ),
              const SizedBox(height: 6),
              TextButton(
                onPressed: () {
                  // TODO: Navigate to payment / confirmation
                },
                child: const Text(
                  "Select",
                  style: TextStyle(
                    color: Color(0xFF0D7C7B),
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
